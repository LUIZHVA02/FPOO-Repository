package br.senai.sp.jandira;

public class OperadoresLogicos {

	public static void main(String[] args) {
		
		
		int x = 115;
	
	if (x % 2 == 1 && x > 100) {
		System.out.println("Esse valor é impar e maior que 100");
	}
	else {
		System.out.println("Não quero esse valor!");
		
	}
		
	}
}
