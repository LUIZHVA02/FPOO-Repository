package br.senai.sp.jandira;

import java.util.Scanner;

public class Atividade14 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int valorMin = 0, valorMax = 0, valorA = 0, valorB = 0, valor1 = 0, valor2 = 0, multiplicando = 0;
		
		System.out.println("----------------------------------------");
		System.out.println("----------------TABUADAS----------------");
		System.out.println("----------------------------------------");
		System.out.println("                                        ");
		System.out.print("Qual Valor Inteiro Deseja Multiplicar: ");
		multiplicando = teclado.nextInt();
		System.out.print("Qual o Menor Valor Multiplicador: ");
		valorA = teclado.nextInt();
		System.out.print("Qual o Maior Valor Multiplicador: ");
		valorB = teclado.nextInt();
		System.out.println("                                       ");
		
		if (valorA > valorB) {
			valorMin = valorA;
			valorMax = valorB;
		}
		if (valorA < valorB) {
			valorMin = valorB;
			valorMax = valorA;
		}
		
		System.out.println("Tabuada do " + multiplicando);
		System.out.println("-----------------------------------");
		System.out.println("                                   ");
		
		
		while (valor1 <= valor2) {
			
			valor1 = multiplicando * valorMin;
			valor2 = multiplicando * valorMax;
			
			if (valor1 %  multiplicando == 0) {
			System.out.println(multiplicando + " x " + valor1 + " = " + (multiplicando * valorMin));
			}
			valorMin++;
			}
		

}
}
