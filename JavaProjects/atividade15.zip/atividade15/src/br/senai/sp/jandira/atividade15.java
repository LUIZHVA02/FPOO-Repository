package br.senai.sp.jandira;

public class atividade15 {

	public static void main(String[] args) {
		
		int valorFinal = 50, valorInicial = 1
				, soma = 0;
		
		for (int v = valorInicial; v <= valorFinal; v++) {
			if (v % 2 == 0)
			soma += v; {
			}
		}
		System.out.println(soma);
		
	}

}
